download = 'https://github.com/brstato/Site_CaixaCerto/releases/download/CaixaCertoSetup/CaixaCerto_setup.exe'
