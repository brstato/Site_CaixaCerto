# CaixaCerto_Site
Este repositorio visa montar um exemplo de uma pagina estatica feita em flet python, a pagina serve para trazer usuarios ao app CaixaCerto
